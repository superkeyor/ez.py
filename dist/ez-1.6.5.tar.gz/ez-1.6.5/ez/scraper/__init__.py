from webscraper import Scraper
from webscraper import __doc__ as __doc__